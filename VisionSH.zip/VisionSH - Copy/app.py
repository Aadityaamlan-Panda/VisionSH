import os
import time
import ctypes
from PIL import ImageGrab
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials
import threading
import cohere
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas as cav
from reportlab.lib import colors
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase.ttfonts import TTFont

# Initialize Cohere API client
cohere_client = cohere.ClientV2(api_key="YOUR_COHERE_API_KEY")

# Authenticate
subscription_key = "YOUR_AZURE_COMPUTER_VISION_SUBSCRIPTION_KEY"
endpoint = "YOUR_AZURE_COMPUTER_VISION_ENDPOINT"
computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))

# Enable DPI awareness for Windows
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass

# Get scaling factor for DPI adjustments
def get_scaling_factor():
    hdc = ctypes.windll.user32.GetDC(0)
    dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, 88)  # LOGPIXELSX
    ctypes.windll.user32.ReleaseDC(0, hdc)
    return dpi / 96  # Default DPI is 96

scaling_factor = get_scaling_factor()
print("Scaling Factor:", scaling_factor)

# Function for OCR on local image
def perform_ocr_local(image_path):
    output = []
    with open(image_path, "rb") as image:
        read_response = computervision_client.read_in_stream(image, raw=True)

    read_operation_location = read_response.headers["Operation-Location"]
    operation_id = read_operation_location.split("/")[-1]

    while True:
        read_result = computervision_client.get_read_result(operation_id)
        if read_result.status not in ['notStarted', 'running']:
            break
        time.sleep(1)

    if read_result.status == OperationStatusCodes.succeeded:
        for text_result in read_result.analyze_result.read_results:
            for line in text_result.lines:
                output.append(line.text)
    return output

# Function for tagging local image and generating description
def tag_image_local(image_path):
    with open(image_path, "rb") as image:
        tags_result = computervision_client.tag_image_in_stream(image)

    tags = [tag.name for tag in tags_result.tags]

    if tags:
        # Send tags to Cohere AI for description generation
        ai_description = generate_description_from_tags(tags)
        return ai_description
    else:
        return "No meaningful tags could be detected."

def generate_description_from_tags(tags):
    """
    Generate a description using Cohere's language model based on the given tags.
    """
    prompt = (
        f"The following are tags describing the contents of an image: {', '.join(tags)}.\n"
        "Write a detailed, human-like description of the image in a creative and natural tone. Do not be overexpressive and try to stick to the point. If possible try to predict the main idea of the image"
    )

    try:
        response = cohere_client.chat(
            model="command-r-plus-08-2024",  # Choose the appropriate model
            messages=[
        {
            "role": "user",
            "content": prompt,
        },
           ]             )
        description = response.message.content[0].text
        return description
    except Exception as e:
        return f"Failed to generate description: {str(e)}"


# Function to capture screenshot and process it
def capture_screenshot(rect):
    # Adjust width and height using the scaling factor
    screen_width = ctypes.windll.user32.GetSystemMetrics(0)
    screen_height = ctypes.windll.user32.GetSystemMetrics(1)
    adjusted_rect = (
        max(0,int(rect[0])),  # Top-left x (no scaling for starting point)
        max(0,int(rect[1])),  # Top-left y (no scaling for starting point)
        min(screen_width,int(rect[0] + (rect[2] - rect[0]) * 1)),  # Bottom-right x
        min(screen_height,int(rect[1] + (rect[3] - rect[1]) * 1)),  # Bottom-right y
    )

    # Debugging: Print original and adjusted rectangle details
    print(f"Original Rectangle: {rect}")
    print(f"Adjusted Rectangle (for ImageGrab): {adjusted_rect}")
    print(f"Screen Dimensions: {ctypes.windll.user32.GetSystemMetrics(0)}x{ctypes.windll.user32.GetSystemMetrics(1)}")

    # Capture the screenshot using the adjusted rectangle
    screenshot = ImageGrab.grab(bbox=adjusted_rect)

    # Save the captured screenshot
    screenshot_path = "snipped_image.png"
    screenshot.save(screenshot_path, "PNG")
    return screenshot_path


# Function to process the image (runs in a worker thread)
def process_image(rect, ocr_text, description_text):
    image_path = capture_screenshot(rect)

    # Perform OCR and Image Tagging
    ocr_results = perform_ocr_local(image_path)
    image_description = tag_image_local(image_path)

    # Update the results in the GUI (main thread)
    def update_gui():
        if ocr_results:
            ocr_text.set("\n".join(ocr_results))
        else:
            ocr_text.set("No text detected.")

        description_text.set(image_description)

        # Save results to PDF
        save_to_pdf(ocr_results, image_description)

    root.after(0, update_gui)



def save_to_pdf(ocr_results, description):
    pdf_filename = "image_analysis_results.pdf"
    c = cav.Canvas(pdf_filename, pagesize=letter)
    width, height = letter

    # Custom margins
    left_margin = 50
    right_margin = 50
    top_margin = 60
    bottom_margin = 50
    max_width = width - left_margin - right_margin

    # Set background color (light blue)
    c.setFillColor(colors.lightblue)
    c.rect(0, 0, width, height, fill=True)

    # Title section with a beautiful font style
    c.setFont("Helvetica-Bold", 20)
    c.setFillColor(colors.darkblue)
    c.drawString(left_margin, height - top_margin, "Image Analysis Results")

    # Adjust starting position
    y_position = height - top_margin - 40

    # Add OCR Results with custom styling
    c.setFont("Helvetica-Bold", 14)
    c.setFillColor(colors.black)
    c.drawString(left_margin, y_position, "OCR Results:")
    y_position -= 30

    # Draw wrapped text for OCR Results
    for line in ocr_results:
        wrapped_lines = wrap_text(line, "Helvetica-Bold", 14, max_width)
        for wrapped_line in wrapped_lines:
            if y_position < bottom_margin:  # Check for page overflow
                c.showPage()
                y_position = height - top_margin
                c.setFont("Helvetica-Bold", 14)
                c.setFillColor(colors.black)
            c.drawString(left_margin, y_position, wrapped_line)
            y_position -= 18

    # Add space between OCR results and description
    y_position -= 30
    c.setFont("Helvetica-Bold", 14)
    c.setFillColor(colors.darkgreen)
    c.drawString(left_margin, y_position, "Image Description:")
    y_position -= 30

    # Draw wrapped text for Image Description with additional styling
    wrapped_description = wrap_text(description, "Helvetica", 14, max_width)
    for wrapped_line in wrapped_description:
        if y_position < bottom_margin:  # Check for page overflow
            c.showPage()
            y_position = height - top_margin
            c.setFont("Helvetica", 14)
            c.setFillColor(colors.black)
        c.drawString(left_margin, y_position, wrapped_line)
        y_position -= 18

    # Save the PDF
    c.save()
    messagebox.showinfo("Success", f"Results saved as {pdf_filename}")

def wrap_text(text, font_name, font_size, max_width):
    """
    Wrap text into lines that fit within the specified width.
    """
    words = text.split()
    wrapped_lines = []
    current_line = ""

    for word in words:
        if stringWidth(current_line + " " + word, font_name, font_size) <= max_width:
            current_line += " " + word if current_line else word
        else:
            wrapped_lines.append(current_line)
            current_line = word

    if current_line:
        wrapped_lines.append(current_line)

    return wrapped_lines



# Function to handle snipping window
def snip_and_process(ocr_text, description_text):
    def on_release(event):
        rect = (start_x, start_y, event.x, event.y)
        snip_root.destroy()

        # Start worker thread for processing the image
        threading.Thread(target=process_image, args=(rect, ocr_text, description_text)).start()

    snip_root = tk.Toplevel()
    snip_root.attributes("-fullscreen", True)
    snip_root.attributes("-alpha", 0.3)
    snip_root.configure(cursor="cross")

    canvas = tk.Canvas(snip_root, bg="gray")
    canvas.pack(fill=tk.BOTH, expand=True)

    start_x, start_y = 0, 0
    rect_id = None  # To track the rectangle ID

    def on_press(event):
        nonlocal start_x, start_y, rect_id
        start_x, start_y = event.x, event.y
        if rect_id:  # Clear any existing rectangle
            canvas.delete(rect_id)
        rect_id = None  # Reset rectangle ID

    def on_drag(event):
        nonlocal rect_id
        if rect_id:  # Clear the previous rectangle
            canvas.delete(rect_id)
        rect_id = canvas.create_rectangle(start_x, start_y, event.x, event.y, outline="red", width=2)

    canvas.bind("<ButtonPress-1>", on_press)
    canvas.bind("<B1-Motion>", on_drag)
    canvas.bind("<ButtonRelease-1>", on_release)


# GUI Setup
# GUI Setup
root = tk.Tk()
root.title("Azure Vision Image Analysis")
root.geometry("50x200")  # Adjust window size for vertical button
root.overrideredirect(True)
window_width = 50
window_height = 150

# Get the screen width and height
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Calculate the x and y positions to place the window on the right side and center it vertically
x_position = screen_width - window_width  # Position the window at the right edge
y_position = (screen_height - window_height) // 2  # Center the window vertically

# Set the window size and position
root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")
ocr_text = tk.StringVar(value="No results yet...")
description_text = tk.StringVar(value="No results yet...")

# Create a Canvas to rotate the button's text
canvas = tk.Canvas(root, width=50, height=200, bg='lightblue', relief='raised')
canvas.place(relx=1, rely=0.5, anchor='e')

# Add the vertical text to the canvas (acting as a button)
canvas.create_text(25, 100, text="Start Snipping", angle=90, font=("Helvetica", 12), fill="black")

# Function to bind click event on the canvas (simulating button behavior)
def on_canvas_click(event):
    snip_and_process(ocr_text, description_text)

# Bind the click event to the canvas
canvas.bind("<Button-1>", on_canvas_click)

root.mainloop()